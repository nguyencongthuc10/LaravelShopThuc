
@extends('admin/master')
@section('noidungadmin')

	<H2>Chào mừng bạn đến với trang Admin</H2>

@endsection